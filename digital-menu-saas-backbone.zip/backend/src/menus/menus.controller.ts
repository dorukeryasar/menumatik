import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  UseGuards,
} from '@nestjs/common';
import { MenusService } from './menus.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TenantGuard } from '../common/guards/tenant.guard';
import { CreateCategoryDto, UpdateCategoryDto } from './dto/category.dto';

// All routes here are nested under /businesses/:businessId so
// TenantGuard can enforce tenant scoping consistently across the app.
@UseGuards(JwtAuthGuard, TenantGuard)
@Controller('businesses/:businessId/menu')
export class MenusController {
  constructor(private menusService: MenusService) {}

  @Get()
  getMenu(@Param('businessId') businessId: string) {
    return this.menusService.getMenuWithCategories(businessId);
  }

  @Post('categories')
  createCategory(
    @Param('businessId') businessId: string,
    @Body() dto: CreateCategoryDto,
  ) {
    return this.menusService.createCategory(businessId, dto);
  }

  @Patch('categories/:categoryId')
  updateCategory(
    @Param('businessId') businessId: string,
    @Param('categoryId') categoryId: string,
    @Body() dto: UpdateCategoryDto,
  ) {
    return this.menusService.updateCategory(businessId, categoryId, dto);
  }

  @Delete('categories/:categoryId')
  deleteCategory(
    @Param('businessId') businessId: string,
    @Param('categoryId') categoryId: string,
  ) {
    return this.menusService.deleteCategory(businessId, categoryId);
  }
}
