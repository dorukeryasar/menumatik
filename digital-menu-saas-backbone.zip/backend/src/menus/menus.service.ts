import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCategoryDto, UpdateCategoryDto } from './dto/category.dto';

@Injectable()
export class MenusService {
  constructor(private prisma: PrismaService) {}

  async getMenuWithCategories(businessId: string) {
    const menu = await this.prisma.menu.findFirst({
      where: { businessId }, // scoped — TenantGuard already checked the
                              // businessId in the URL matches the JWT,
                              // but the service layer scopes again too.
      include: {
        categories: {
          orderBy: { sortOrder: 'asc' },
          include: { items: { orderBy: { sortOrder: 'asc' } } },
        },
      },
    });
    if (!menu) throw new NotFoundException('Menu not found for this business');
    return menu;
  }

  async createCategory(businessId: string, dto: CreateCategoryDto) {
    const menu = await this.prisma.menu.findFirst({ where: { businessId } });
    if (!menu) throw new NotFoundException('Menu not found for this business');

    return this.prisma.category.create({
      data: {
        menuId: menu.id,
        name: dto.name,
        sortOrder: dto.sortOrder ?? 0,
      },
    });
  }

  async updateCategory(businessId: string, categoryId: string, dto: UpdateCategoryDto) {
    await this.assertCategoryBelongsToBusiness(businessId, categoryId);
    return this.prisma.category.update({
      where: { id: categoryId },
      data: dto,
    });
  }

  async deleteCategory(businessId: string, categoryId: string) {
    await this.assertCategoryBelongsToBusiness(businessId, categoryId);
    // onDelete: Cascade in the schema means this also removes all
    // Items under this category. Confirm this is the desired UX on
    // the frontend before calling this endpoint (consider a confirm
    // dialog: "This will delete N items").
    return this.prisma.category.delete({ where: { id: categoryId } });
  }

  /**
   * Critical check: confirms the category being modified actually
   * belongs (via menu -> business) to the businessId from the
   * authenticated request. Without this, an owner of Business A
   * could pass Business B's categoryId in the URL and edit it,
   * since :categoryId alone carries no tenant info.
   */
  private async assertCategoryBelongsToBusiness(businessId: string, categoryId: string) {
    const category = await this.prisma.category.findFirst({
      where: { id: categoryId, menu: { businessId } },
    });
    if (!category) {
      throw new NotFoundException('Category not found');
    }
    return category;
  }
}
