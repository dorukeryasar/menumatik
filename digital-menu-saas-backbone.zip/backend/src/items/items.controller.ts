import {
  Controller,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  UseGuards,
} from '@nestjs/common';
import { ItemsService } from './items.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TenantGuard } from '../common/guards/tenant.guard';
import { CreateItemDto, UpdateItemDto } from './dto/item.dto';

@UseGuards(JwtAuthGuard, TenantGuard)
@Controller('businesses/:businessId')
export class ItemsController {
  constructor(private itemsService: ItemsService) {}

  @Post('categories/:categoryId/items')
  createItem(
    @Param('businessId') businessId: string,
    @Param('categoryId') categoryId: string,
    @Body() dto: CreateItemDto,
  ) {
    return this.itemsService.createItem(businessId, categoryId, dto);
  }

  @Patch('items/:itemId')
  updateItem(
    @Param('businessId') businessId: string,
    @Param('itemId') itemId: string,
    @Body() dto: UpdateItemDto,
  ) {
    return this.itemsService.updateItem(businessId, itemId, dto);
  }

  @Patch('items/:itemId/toggle-availability')
  toggleAvailability(
    @Param('businessId') businessId: string,
    @Param('itemId') itemId: string,
  ) {
    return this.itemsService.toggleAvailability(businessId, itemId);
  }

  @Delete('items/:itemId')
  deleteItem(
    @Param('businessId') businessId: string,
    @Param('itemId') itemId: string,
  ) {
    return this.itemsService.deleteItem(businessId, itemId);
  }
}
