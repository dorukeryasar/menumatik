import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateItemDto, UpdateItemDto } from './dto/item.dto';

@Injectable()
export class ItemsService {
  constructor(private prisma: PrismaService) {}

  async createItem(businessId: string, categoryId: string, dto: CreateItemDto) {
    await this.assertCategoryBelongsToBusiness(businessId, categoryId);

    // Convert decimal price -> integer cents. Math.round guards
    // against floating point artifacts (e.g. 12.1 * 100 = 1209.99...).
    const priceCents = Math.round(dto.price * 100);

    return this.prisma.item.create({
      data: {
        categoryId,
        name: dto.name,
        description: dto.description,
        priceCents,
        imageUrl: dto.imageUrl,
        isAvailable: dto.isAvailable ?? true,
        modifiers: dto.modifiers
          ? this.modifiersToCents(dto.modifiers)
          : undefined,
      },
    });
  }

  async updateItem(businessId: string, itemId: string, dto: UpdateItemDto) {
    await this.assertItemBelongsToBusiness(businessId, itemId);

    return this.prisma.item.update({
      where: { id: itemId },
      data: {
        ...(dto.name !== undefined && { name: dto.name }),
        ...(dto.description !== undefined && { description: dto.description }),
        ...(dto.price !== undefined && { priceCents: Math.round(dto.price * 100) }),
        ...(dto.imageUrl !== undefined && { imageUrl: dto.imageUrl }),
        ...(dto.isAvailable !== undefined && { isAvailable: dto.isAvailable }),
        ...(dto.modifiers !== undefined && {
          modifiers: this.modifiersToCents(dto.modifiers),
        }),
      },
    });
  }

  async deleteItem(businessId: string, itemId: string) {
    await this.assertItemBelongsToBusiness(businessId, itemId);
    return this.prisma.item.delete({ where: { id: itemId } });
  }

  // Quick "86 this item" toggle — common enough in restaurant
  // workflows (ran out of an ingredient) to deserve its own endpoint
  // rather than forcing a full update payload from the frontend.
  async toggleAvailability(businessId: string, itemId: string) {
    const item = await this.assertItemBelongsToBusiness(businessId, itemId);
    return this.prisma.item.update({
      where: { id: itemId },
      data: { isAvailable: !item.isAvailable },
    });
  }

  private modifiersToCents(
    modifiers: Array<{ name: string; options: Array<{ label: string; price: number }> }>,
  ) {
    return modifiers.map((group) => ({
      name: group.name,
      options: group.options.map((opt) => ({
        label: opt.label,
        priceCents: Math.round(opt.price * 100),
      })),
    }));
  }

  private async assertCategoryBelongsToBusiness(businessId: string, categoryId: string) {
    const category = await this.prisma.category.findFirst({
      where: { id: categoryId, menu: { businessId } },
    });
    if (!category) throw new NotFoundException('Category not found');
    return category;
  }

  private async assertItemBelongsToBusiness(businessId: string, itemId: string) {
    // Traverses item -> category -> menu -> business in one query.
    // This is the pattern to repeat any time you add a new resource
    // nested under a business: always verify the FULL chain, not
    // just the immediate parent.
    const item = await this.prisma.item.findFirst({
      where: { id: itemId, category: { menu: { businessId } } },
    });
    if (!item) throw new NotFoundException('Item not found');
    return item;
  }
}
