import {
  IsString,
  IsOptional,
  IsNumber,
  IsBoolean,
  IsUrl,
  IsArray,
  Min,
  MinLength,
} from 'class-validator';

// Modifier shape, validated loosely here — for an MVP, JSON-shape
// validation via a nested DTO is overkill. Tighten this later if
// modifiers become a heavily-used feature.
export class CreateItemDto {
  @IsString()
  @MinLength(1)
  name: string;

  @IsOptional()
  @IsString()
  description?: string;

  // IMPORTANT: this is a decimal price in major currency units
  // (e.g. 12.50), exactly what a person types in a form. The
  // service layer converts to integer cents before persisting.
  // Never let the frontend send cents directly — that's an easy
  // off-by-100 bug waiting to happen.
  @IsNumber()
  @Min(0)
  price: number;

  @IsOptional()
  @IsUrl()
  imageUrl?: string;

  @IsOptional()
  @IsBoolean()
  isAvailable?: boolean;

  @IsOptional()
  @IsArray()
  modifiers?: Array<{
    name: string;
    options: Array<{ label: string; price: number }>;
  }>;
}

export class UpdateItemDto {
  @IsOptional()
  @IsString()
  @MinLength(1)
  name?: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @IsNumber()
  @Min(0)
  price?: number;

  @IsOptional()
  @IsUrl()
  imageUrl?: string;

  @IsOptional()
  @IsBoolean()
  isAvailable?: boolean;

  @IsOptional()
  @IsArray()
  modifiers?: Array<{
    name: string;
    options: Array<{ label: string; price: number }>;
  }>;
}
