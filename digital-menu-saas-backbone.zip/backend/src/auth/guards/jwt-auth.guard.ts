import { Injectable } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

// Apply with @UseGuards(JwtAuthGuard) on any controller/route that
// requires a logged-in user. Throws 401 automatically if the token
// is missing, malformed, or expired.
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {}
