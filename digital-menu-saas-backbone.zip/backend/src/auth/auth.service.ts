import {
  Injectable,
  ConflictException,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../prisma/prisma.service';
import { RegisterDto } from './dto/register.dto';
import { LoginDto } from './dto/login.dto';
import { slugify } from '../common/utils/slugify';

// Cost factor for bcrypt. 12 is a reasonable default in 2026 —
// high enough to resist brute force, low enough not to choke
// your login endpoint under load. Don't go below 10.
const BCRYPT_ROUNDS = 12;

@Injectable()
export class AuthService {
  constructor(
    private prisma: PrismaService,
    private jwt: JwtService,
  ) {}

  async register(dto: RegisterDto) {
    const existing = await this.prisma.user.findUnique({
      where: { email: dto.email },
    });
    if (existing) {
      // Deliberately vague — don't confirm/deny which emails exist
      // in more security-sensitive contexts, but for B2B signup
      // a clear "already registered" message is fine UX-wise.
      throw new ConflictException('An account with this email already exists');
    }

    const passwordHash = await bcrypt.hash(dto.password, BCRYPT_ROUNDS);
    const slug = await this.generateUniqueSlug(dto.businessName);

    // Create User + Business together. If Business creation fails,
    // we don't want an orphaned User row — wrap in a transaction.
    const result = await this.prisma.$transaction(async (tx) => {
      const user = await tx.user.create({
        data: {
          email: dto.email,
          passwordHash,
          role: 'OWNER',
        },
      });

      const business = await tx.business.create({
        data: {
          ownerId: user.id,
          name: dto.businessName,
          slug,
        },
      });

      // Every new business starts with one empty menu so the
      // dashboard has something to render immediately.
      await tx.menu.create({
        data: {
          businessId: business.id,
          name: 'Main Menu',
        },
      });

      return { user, business };
    });

    return this.buildAuthResponse(result.user.id, result.user.email, result.business.id);
  }

  async login(dto: LoginDto) {
    const user = await this.prisma.user.findUnique({
      where: { email: dto.email },
      include: { business: true },
    });

    // Same error for "no user" and "wrong password" — don't leak
    // which emails are registered via response differences.
    if (!user) {
      throw new UnauthorizedException('Invalid email or password');
    }

    const passwordValid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!passwordValid) {
      throw new UnauthorizedException('Invalid email or password');
    }

    return this.buildAuthResponse(user.id, user.email, user.business?.id);
  }

  private buildAuthResponse(userId: string, email: string, businessId?: string) {
    // businessId is embedded directly in the JWT payload. This is
    // what the TenantGuard reads later — it means every authenticated
    // request already carries its tenant scope without an extra DB
    // lookup on every call.
    const payload = { sub: userId, email, businessId };
    return {
      accessToken: this.jwt.sign(payload),
      user: { id: userId, email, businessId },
    };
  }

  private async generateUniqueSlug(businessName: string): Promise<string> {
    const base = slugify(businessName) || 'business';
    let candidate = base;
    let attempt = 0;

    while (await this.prisma.business.findUnique({ where: { slug: candidate } })) {
      attempt++;
      candidate = `${base}-${Math.random().toString(36).slice(2, 6)}`;
      if (attempt > 5) break; // safety valve, extremely unlikely to hit
    }

    return candidate;
  }
}
