import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';

// @Global() means you don't need to import PrismaModule in every
// feature module — just inject PrismaService directly.
@Global()
@Module({
  providers: [PrismaService],
  exports: [PrismaService],
})
export class PrismaModule {}
