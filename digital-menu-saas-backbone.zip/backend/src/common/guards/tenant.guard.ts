import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
} from '@nestjs/common';

/**
 * TENANT ISOLATION GUARD
 * ----------------------------------------------------------------
 * This is the single most important guard in the codebase. Read
 * this comment before touching it.
 *
 * The whole platform is multi-tenant: every Business's menus,
 * items, and orders must be invisible to every other Business.
 * The JWT issued at login already carries `businessId` (see
 * AuthService.buildAuthResponse). This guard's job is simple:
 *
 *   "Does req.user.businessId match the :businessId in the URL
 *    the request is trying to act on?"
 *
 * If not, it throws 403 — before the controller or Prisma query
 * even runs. This means a leaked or guessed businessId/resource id
 * in a URL can NEVER return another tenant's data, even if a
 * developer later forgets a `where: { businessId }` clause deeper
 * in the service layer. Treat this guard as the backstop, not the
 * only line of defense — service-layer queries should STILL scope
 * by businessId explicitly. Defense in depth.
 *
 * Apply it on any route shaped like:
 *   /businesses/:businessId/...
 *
 * Usage:
 *   @UseGuards(JwtAuthGuard, TenantGuard)
 *   @Get('businesses/:businessId/menus')
 */
@Injectable()
export class TenantGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user = request.user; // set by JwtAuthGuard, runs first
    const requestedBusinessId = request.params.businessId;

    if (!user?.businessId) {
      throw new ForbiddenException('No business associated with this account');
    }

    if (!requestedBusinessId) {
      // Route doesn't have a :businessId param — misconfigured usage
      // of this guard. Fail closed rather than silently passing.
      throw new ForbiddenException('Tenant context missing from request');
    }

    if (user.businessId !== requestedBusinessId) {
      throw new ForbiddenException('You do not have access to this resource');
    }

    return true;
  }
}
