import { createParamDecorator, ExecutionContext } from '@nestjs/common';

// Usage in a controller: getDashboard(@CurrentUser() user: AuthUser) { ... }
// Pulls req.user (set by JwtStrategy.validate) without controllers
// needing to know about the Request object directly.
export const CurrentUser = createParamDecorator(
  (data: unknown, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest();
    return request.user;
  },
);
