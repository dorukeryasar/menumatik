/**
 * Turns "Joe's Pizza & Grill" into "joes-pizza-grill".
 * The AuthService appends a short random suffix if the slug
 * is already taken (see auth.service.ts) rather than failing
 * registration outright.
 */
export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '') // strip punctuation/special chars
    .replace(/\s+/g, '-')         // spaces -> hyphens
    .replace(/-+/g, '-')          // collapse multiple hyphens
    .replace(/^-|-$/g, '');       // trim leading/trailing hyphens
}
