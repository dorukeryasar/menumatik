import {
  Controller,
  Get,
  Post,
  Patch,
  Param,
  Body,
  Query,
  UseGuards,
} from '@nestjs/common';
import { OrdersService } from './orders.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TenantGuard } from '../common/guards/tenant.guard';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderStatusDto } from './dto/update-order-status.dto';

@Controller()
export class OrdersController {
  constructor(private ordersService: OrdersService) {}

  // ---- PUBLIC: customer checkout, no auth ----
  // Rate-limited globally via ThrottlerModule in app.module.ts.
  // This is the single most abuse-prone endpoint on the platform —
  // anyone on the internet can hit it. Validation + server-side
  // price calc (see OrdersService) are what keep it safe.
  @Post('public/businesses/:businessId/orders')
  createOrder(
    @Param('businessId') businessId: string,
    @Body() dto: CreateOrderDto,
  ) {
    return this.ordersService.createOrder(businessId, dto);
    // TODO (Sprint 8-9): wrap this in Stripe PaymentIntent creation.
    // Order is created as PENDING/UNPAID immediately; a Stripe
    // webhook handler (separate controller, raw-body parsing,
    // signature verification) flips it to CONFIRMED/PAID once
    // Stripe confirms the charge. Never trust a "payment succeeded"
    // signal that arrives directly from the frontend.
  }

  // ---- PROTECTED: owner's order management dashboard ----
  @UseGuards(JwtAuthGuard, TenantGuard)
  @Get('businesses/:businessId/orders')
  getOrders(
    @Param('businessId') businessId: string,
    @Query('status') status?: string,
  ) {
    return this.ordersService.getOrdersForBusiness(businessId, status);
  }

  @UseGuards(JwtAuthGuard, TenantGuard)
  @Get('businesses/:businessId/orders/:orderId')
  getOrder(
    @Param('businessId') businessId: string,
    @Param('orderId') orderId: string,
  ) {
    return this.ordersService.getOrderById(businessId, orderId);
  }

  @UseGuards(JwtAuthGuard, TenantGuard)
  @Patch('businesses/:businessId/orders/:orderId/status')
  updateStatus(
    @Param('businessId') businessId: string,
    @Param('orderId') orderId: string,
    @Body() dto: UpdateOrderStatusDto,
  ) {
    return this.ordersService.updateStatus(businessId, orderId, dto);
  }
}
