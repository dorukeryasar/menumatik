import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderStatusDto } from './dto/update-order-status.dto';

@Injectable()
export class OrdersService {
  constructor(private prisma: PrismaService) {}

  /**
   * Creates an order for a PUBLIC (unauthenticated) checkout flow.
   *
   * SECURITY-CRITICAL: the cart total is NEVER trusted from the
   * client. A customer's browser sends only itemId + quantity +
   * which modifier options they picked. This function looks up
   * every item's REAL current price from the database and computes
   * the total server-side. If you ever accept a `totalCents` field
   * from the request body here, you've created a price-tampering
   * vulnerability — someone can submit any total they want via
   * devtools/Postman.
   */
  async createOrder(businessId: string, dto: CreateOrderDto) {
    const business = await this.prisma.business.findUnique({
      where: { id: businessId, isActive: true },
    });
    if (!business) throw new NotFoundException('Business not found');

    const itemIds = dto.items.map((i) => i.itemId);
    const dbItems = await this.prisma.item.findMany({
      where: {
        id: { in: itemIds },
        isAvailable: true,
        category: { menu: { businessId } }, // ensures items actually belong to this business
      },
    });

    const dbItemMap = new Map(dbItems.map((item) => [item.id, item]));

    let totalCents = 0;
    const orderItemsData: Array<{
      itemId: string;
      quantity: number;
      unitPriceCents: number;
      selectedModifiers: unknown;
      notes?: string;
    }> = [];

    for (const cartItem of dto.items) {
      const dbItem = dbItemMap.get(cartItem.itemId);
      if (!dbItem) {
        // Item doesn't exist, isn't available, or doesn't belong to
        // this business — reject the whole order rather than
        // silently dropping the line item (customer should know).
        throw new BadRequestException(
          `Item ${cartItem.itemId} is unavailable or invalid`,
        );
      }

      let unitPriceCents = dbItem.priceCents;

      // Add modifier option prices, looked up server-side from the
      // item's stored modifiers JSON — never from client input.
      if (cartItem.selectedModifiers?.length) {
        const modifierGroups = (dbItem.modifiers as any[]) || [];
        for (const sel of cartItem.selectedModifiers) {
          const group = modifierGroups[sel.groupIndex];
          const option = group?.options?.[sel.optionIndex];
          if (option) {
            unitPriceCents += option.priceCents;
          }
        }
      }

      totalCents += unitPriceCents * cartItem.quantity;

      orderItemsData.push({
        itemId: dbItem.id,
        quantity: cartItem.quantity,
        unitPriceCents,
        selectedModifiers: cartItem.selectedModifiers ?? null,
        notes: cartItem.notes,
      });
    }

    const order = await this.prisma.order.create({
      data: {
        businessId,
        guestName: dto.guestName,
        guestPhone: dto.guestPhone,
        orderType: dto.orderType,
        notes: dto.notes,
        totalCents,
        status: 'PENDING',
        paymentStatus: 'UNPAID',
        items: {
          create: orderItemsData,
        },
      },
      include: { items: true },
    });

    return order;
    // Next step in the flow (Sprint 8-9 from the roadmap): create a
    // Stripe PaymentIntent for `totalCents` and return its
    // client_secret to the frontend. Order status flips to
    // CONFIRMED only after the webhook confirms payment — see the
    // note in OrdersController for where that hook will live.
  }

  // --- OWNER DASHBOARD: scoped to their business only ---

  async getOrdersForBusiness(businessId: string, status?: string) {
    return this.prisma.order.findMany({
      where: {
        businessId,
        ...(status && { status: status as any }),
      },
      include: { items: { include: { item: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getOrderById(businessId: string, orderId: string) {
    const order = await this.prisma.order.findFirst({
      where: { id: orderId, businessId }, // tenant-scoped lookup
      include: { items: { include: { item: true } } },
    });
    if (!order) throw new NotFoundException('Order not found');
    return order;
  }

  async updateStatus(businessId: string, orderId: string, dto: UpdateOrderStatusDto) {
    // Confirms the order belongs to this business before mutating it.
    await this.getOrderById(businessId, orderId);
    return this.prisma.order.update({
      where: { id: orderId },
      data: { status: dto.status },
    });
  }
}
