import {
  IsString,
  IsArray,
  IsOptional,
  IsEnum,
  ValidateNested,
  IsInt,
  Min,
  ArrayMinSize,
} from 'class-validator';
import { Type } from 'class-transformer';

export enum OrderTypeDto {
  PICKUP = 'PICKUP',
  DELIVERY = 'DELIVERY',
  DINE_IN = 'DINE_IN',
}

class OrderItemInputDto {
  @IsString()
  itemId: string;

  @IsInt()
  @Min(1)
  quantity: number;

  // Indices into the item's stored modifier options, sent by the
  // frontend so the backend can look up actual prices server-side.
  // Shape: [{ groupIndex: 0, optionIndex: 1 }]
  @IsOptional()
  @IsArray()
  selectedModifiers?: Array<{ groupIndex: number; optionIndex: number }>;

  @IsOptional()
  @IsString()
  notes?: string;
}

export class CreateOrderDto {
  @IsArray()
  @ArrayMinSize(1, { message: 'Cart cannot be empty' })
  @ValidateNested({ each: true })
  @Type(() => OrderItemInputDto)
  items: OrderItemInputDto[];

  @IsEnum(OrderTypeDto)
  orderType: OrderTypeDto;

  @IsOptional()
  @IsString()
  guestName?: string;

  @IsOptional()
  @IsString()
  guestPhone?: string;

  @IsOptional()
  @IsString()
  notes?: string;
}
