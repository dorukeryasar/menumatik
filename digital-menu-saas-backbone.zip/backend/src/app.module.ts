import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule } from '@nestjs/throttler';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { BusinessesModule } from './businesses/businesses.module';
import { MenusModule } from './menus/menus.module';
import { ItemsModule } from './items/items.module';
import { OrdersModule } from './orders/orders.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),

    // Basic rate limiting — important on public endpoints
    // (menu reads, checkout) since they're unauthenticated.
    ThrottlerModule.forRoot([
      {
        ttl: 60000, // 1 minute window
        limit: 100, // 100 requests per IP per window
      },
    ]),

    PrismaModule,
    AuthModule,
    BusinessesModule,
    MenusModule,
    ItemsModule,
    OrdersModule,
  ],
})
export class AppModule {}
