import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { UpdateBusinessDto } from './dto/update-business.dto';

@Injectable()
export class BusinessesService {
  constructor(private prisma: PrismaService) {}

  // --- OWNER-FACING (protected by JwtAuthGuard + TenantGuard) ---

  async getOwnProfile(businessId: string) {
    const business = await this.prisma.business.findUnique({
      where: { id: businessId },
    });
    if (!business) throw new NotFoundException('Business not found');
    return business;
  }

  async updateProfile(businessId: string, dto: UpdateBusinessDto) {
    // businessId comes from the JWT/TenantGuard, never from the
    // request body — so there's no way to pass `{ id: "other-id" }`
    // in the DTO and update someone else's business. The DTO has
    // no `id` field at all, by design.
    return this.prisma.business.update({
      where: { id: businessId },
      data: dto,
    });
  }

  // --- PUBLIC-FACING (no auth — this is what customers see) ---

  async getPublicMenuBySlug(slug: string) {
    const business = await this.prisma.business.findUnique({
      where: { slug, isActive: true },
      select: {
        id: true,
        name: true,
        slug: true,
        logoUrl: true,
        description: true,
        phone: true,
        whatsappNumber: true,
        address: true,
        socialLinks: true,
        currency: true,
        menus: {
          where: { isActive: true },
          select: {
            id: true,
            name: true,
            categories: {
              orderBy: { sortOrder: 'asc' },
              select: {
                id: true,
                name: true,
                items: {
                  where: { isAvailable: true }, // never expose 86'd items publicly
                  orderBy: { sortOrder: 'asc' },
                  select: {
                    id: true,
                    name: true,
                    description: true,
                    priceCents: true,
                    imageUrl: true,
                    modifiers: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!business) {
      throw new NotFoundException('Menu not found');
    }

    // Note what's deliberately excluded from this `select`:
    // stripeAccountId, ownerId, isActive flag, createdAt/updatedAt.
    // Public endpoints should always use an explicit `select`
    // allowlist rather than returning the full row — this is the
    // habit that prevents accidental data leaks as the schema grows.
    return business;
  }
}
