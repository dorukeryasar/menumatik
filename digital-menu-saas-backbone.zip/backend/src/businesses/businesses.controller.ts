import {
  Controller,
  Get,
  Patch,
  Param,
  Body,
  UseGuards,
} from '@nestjs/common';
import { BusinessesService } from './businesses.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { TenantGuard } from '../common/guards/tenant.guard';
import { UpdateBusinessDto } from './dto/update-business.dto';

@Controller()
export class BusinessesController {
  constructor(private businessesService: BusinessesService) {}

  // ---- PROTECTED: owner dashboard ----
  // Guard order matters: JwtAuthGuard runs first (populates req.user),
  // then TenantGuard checks req.user.businessId against :businessId.
  @UseGuards(JwtAuthGuard, TenantGuard)
  @Get('businesses/:businessId')
  async getProfile(@Param('businessId') businessId: string) {
    return this.businessesService.getOwnProfile(businessId);
  }

  @UseGuards(JwtAuthGuard, TenantGuard)
  @Patch('businesses/:businessId')
  async updateProfile(
    @Param('businessId') businessId: string,
    @Body() dto: UpdateBusinessDto,
  ) {
    return this.businessesService.updateProfile(businessId, dto);
  }

  // ---- PUBLIC: what an end-customer sees, no auth required ----
  // e.g. GET /public/menu/joes-pizza
  @Get('public/menu/:slug')
  async getPublicMenu(@Param('slug') slug: string) {
    return this.businessesService.getPublicMenuBySlug(slug);
  }
}
