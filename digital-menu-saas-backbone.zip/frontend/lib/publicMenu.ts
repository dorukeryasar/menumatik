import { api } from './api';

export interface PublicItem {
  id: string;
  name: string;
  description?: string;
  priceCents: number;
  imageUrl?: string;
  modifiers?: Array<{
    name: string;
    options: Array<{ label: string; priceCents: number }>;
  }>;
}

export interface PublicCategory {
  id: string;
  name: string;
  items: PublicItem[];
}

export interface PublicMenu {
  id: string;
  name: string;
  categories: PublicCategory[];
}

export interface PublicBusiness {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;
  description?: string;
  phone?: string;
  whatsappNumber?: string;
  address?: string;
  socialLinks?: Record<string, string>;
  currency: string;
  menus: PublicMenu[];
}

export async function getPublicMenu(slug: string): Promise<PublicBusiness> {
  const { data } = await api.get(`/public/menu/${slug}`);
  return data;
}

export interface CartLine {
  itemId: string;
  name: string;
  quantity: number;
  unitPriceCents: number; // for display only — backend recalculates authoritatively
}

export async function submitOrder(
  businessId: string,
  payload: {
    items: Array<{ itemId: string; quantity: number }>;
    orderType: 'PICKUP' | 'DELIVERY' | 'DINE_IN';
    guestName?: string;
    guestPhone?: string;
    notes?: string;
  },
) {
  const { data } = await api.post(`/public/businesses/${businessId}/orders`, payload);
  return data;
}
