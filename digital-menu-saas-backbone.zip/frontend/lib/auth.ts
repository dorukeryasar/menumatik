import { api } from './api';

export interface AuthResponse {
  accessToken: string;
  user: {
    id: string;
    email: string;
    businessId?: string;
  };
}

export async function registerAccount(payload: {
  email: string;
  password: string;
  businessName: string;
}): Promise<AuthResponse> {
  const { data } = await api.post<AuthResponse>('/auth/register', payload);
  return data;
}

export async function login(payload: {
  email: string;
  password: string;
}): Promise<AuthResponse> {
  const { data } = await api.post<AuthResponse>('/auth/login', payload);
  return data;
}

// Call this right after register/login resolves to persist the
// session. Centralized here so both forms behave identically.
export function persistSession(res: AuthResponse) {
  localStorage.setItem('accessToken', res.accessToken);
  if (res.user.businessId) {
    localStorage.setItem('businessId', res.user.businessId);
  }
}

export function logout() {
  localStorage.removeItem('accessToken');
  localStorage.removeItem('businessId');
  window.location.href = '/login';
}

export function getStoredBusinessId(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem('businessId');
}
