import axios from 'axios';

// Single axios instance for the whole app. Every request goes
// through this — don't import axios directly elsewhere, or you'll
// bypass the auth header injection and 401 handling below.
export const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001',
});

// Attach the JWT to every outgoing request, if we have one.
// Token lives in localStorage for this MVP. (Tradeoff: localStorage
// is vulnerable to XSS reading it; httpOnly cookies are more secure
// but require CSRF handling on the backend. For a fast MVP this is
// an acceptable starting point — revisit before handling real
// payment data at scale.)
api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('accessToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

// Global 401 handling: if the token is expired/invalid, clear it
// and bounce to login. This means individual dashboard pages don't
// need to handle "session expired" themselves.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401 && typeof window !== 'undefined') {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('businessId');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  },
);
