import { api } from './api';

export interface Item {
  id: string;
  name: string;
  description?: string;
  priceCents: number;
  imageUrl?: string;
  isAvailable: boolean;
}

export interface Category {
  id: string;
  name: string;
  sortOrder: number;
  items: Item[];
}

export interface MenuResponse {
  id: string;
  name: string;
  categories: Category[];
}

export async function getMenu(businessId: string): Promise<MenuResponse> {
  const { data } = await api.get(`/businesses/${businessId}/menu`);
  return data;
}

export async function createCategory(businessId: string, name: string) {
  const { data } = await api.post(`/businesses/${businessId}/menu/categories`, {
    name,
  });
  return data as Category;
}

export async function deleteCategory(businessId: string, categoryId: string) {
  await api.delete(`/businesses/${businessId}/menu/categories/${categoryId}`);
}

// Note: `price` here is a decimal (e.g. 12.5), matching CreateItemDto
// on the backend exactly. The backend converts to cents — the
// frontend should never do that conversion itself, to keep a single
// source of truth for the math.
export async function createItem(
  businessId: string,
  categoryId: string,
  payload: { name: string; description?: string; price: number; imageUrl?: string },
) {
  const { data } = await api.post(
    `/businesses/${businessId}/categories/${categoryId}/items`,
    payload,
  );
  return data as Item;
}

export async function toggleItemAvailability(businessId: string, itemId: string) {
  const { data } = await api.patch(
    `/businesses/${businessId}/items/${itemId}/toggle-availability`,
  );
  return data as Item;
}

export async function deleteItem(businessId: string, itemId: string) {
  await api.delete(`/businesses/${businessId}/items/${itemId}`);
}

// Formats integer cents back into a display string, respecting the
// pattern: cents are the ONLY representation stored/transmitted,
// conversion to a human "$12.50" happens at render time only.
export function formatCents(cents: number, currency = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(cents / 100);
}
