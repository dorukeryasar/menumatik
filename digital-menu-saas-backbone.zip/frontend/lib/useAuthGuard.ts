'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getStoredBusinessId } from './auth';

/**
 * Client-side guard for dashboard pages. Redirects to /login if
 * there's no token/businessId in localStorage.
 *
 * IMPORTANT: this is a UX convenience, NOT a security boundary.
 * Someone can still call the API directly with a forged/missing
 * token — the real security enforcement is server-side
 * (JwtAuthGuard + TenantGuard in the NestJS backend). Never treat
 * a frontend route guard as sufficient protection on its own.
 */
export function useAuthGuard() {
  const router = useRouter();
  const [businessId, setBusinessId] = useState<string | null>(null);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    const storedBusinessId = getStoredBusinessId();

    if (!token || !storedBusinessId) {
      router.replace('/login');
      return;
    }

    setBusinessId(storedBusinessId);
    setChecked(true);
  }, [router]);

  return { businessId, checked };
}
