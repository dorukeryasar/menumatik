/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      // Add your S3/R2/CDN hostname here once image upload is wired in,
      // e.g. { protocol: 'https', hostname: 'your-bucket.s3.amazonaws.com' }
    ],
  },
};

module.exports = nextConfig;
