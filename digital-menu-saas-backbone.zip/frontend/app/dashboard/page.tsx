'use client';

import { useEffect, useState } from 'react';
import { useAuthGuard } from '@/lib/useAuthGuard';
import { logout } from '@/lib/auth';
import {
  getMenu,
  createCategory,
  deleteCategory,
  createItem,
  toggleItemAvailability,
  deleteItem,
  formatCents,
  type MenuResponse,
} from '@/lib/menu';

export default function DashboardPage() {
  const { businessId, checked } = useAuthGuard();
  const [menu, setMenu] = useState<MenuResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [itemForms, setItemForms] = useState<Record<string, boolean>>({});

  useEffect(() => {
    if (!businessId) return;
    refreshMenu(businessId);
  }, [businessId]);

  async function refreshMenu(bizId: string) {
    setLoading(true);
    try {
      const data = await getMenu(bizId);
      setMenu(data);
    } finally {
      setLoading(false);
    }
  }

  async function handleAddCategory(e: React.FormEvent) {
    e.preventDefault();
    if (!businessId || !newCategoryName.trim()) return;
    await createCategory(businessId, newCategoryName.trim());
    setNewCategoryName('');
    refreshMenu(businessId);
  }

  async function handleDeleteCategory(categoryId: string) {
    if (!businessId) return;
    if (!confirm('Delete this category and all items inside it?')) return;
    await deleteCategory(businessId, categoryId);
    refreshMenu(businessId);
  }

  async function handleToggleAvailability(itemId: string) {
    if (!businessId) return;
    await toggleItemAvailability(businessId, itemId);
    refreshMenu(businessId);
  }

  async function handleDeleteItem(itemId: string) {
    if (!businessId) return;
    await deleteItem(businessId, itemId);
    refreshMenu(businessId);
  }

  if (!checked || loading) {
    return <div className="p-8 text-gray-500">Loading dashboard...</div>;
  }

  return (
    <main className="max-w-3xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-semibold">Menu Dashboard</h1>
        <button onClick={logout} className="text-sm text-gray-500 underline">
          Log out
        </button>
      </div>

      <form onSubmit={handleAddCategory} className="flex gap-2 mb-8">
        <input
          value={newCategoryName}
          onChange={(e) => setNewCategoryName(e.target.value)}
          placeholder="New category name (e.g. Appetizers)"
          className="flex-1 border border-gray-300 rounded-lg px-3 py-2"
        />
        <button
          type="submit"
          className="bg-black text-white px-4 py-2 rounded-lg font-medium"
        >
          Add category
        </button>
      </form>

      <div className="space-y-6">
        {menu?.categories.map((category) => (
          <div
            key={category.id}
            className="bg-white border border-gray-200 rounded-xl p-5"
          >
            <div className="flex justify-between items-center mb-3">
              <h2 className="font-medium text-lg">{category.name}</h2>
              <div className="flex gap-3">
                <button
                  onClick={() =>
                    setItemForms((prev) => ({ ...prev, [category.id]: !prev[category.id] }))
                  }
                  className="text-sm text-blue-600"
                >
                  + Add item
                </button>
                <button
                  onClick={() => handleDeleteCategory(category.id)}
                  className="text-sm text-red-600"
                >
                  Delete category
                </button>
              </div>
            </div>

            {itemForms[category.id] && businessId && (
              <NewItemForm
                businessId={businessId}
                categoryId={category.id}
                onCreated={() => {
                  setItemForms((prev) => ({ ...prev, [category.id]: false }));
                  refreshMenu(businessId);
                }}
              />
            )}

            <ul className="divide-y divide-gray-100">
              {category.items.map((item) => (
                <li key={item.id} className="py-3 flex justify-between items-start">
                  <div>
                    <p className={!item.isAvailable ? 'text-gray-400 line-through' : ''}>
                      {item.name}
                    </p>
                    {item.description && (
                      <p className="text-sm text-gray-500">{item.description}</p>
                    )}
                    <p className="text-sm font-medium mt-1">
                      {formatCents(item.priceCents)}
                    </p>
                  </div>
                  <div className="flex gap-3 text-sm">
                    <button
                      onClick={() => handleToggleAvailability(item.id)}
                      className="text-gray-600 underline"
                    >
                      {item.isAvailable ? 'Mark 86d' : 'Mark available'}
                    </button>
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="text-red-600 underline"
                    >
                      Delete
                    </button>
                  </div>
                </li>
              ))}
              {category.items.length === 0 && (
                <p className="text-sm text-gray-400 py-2">No items yet.</p>
              )}
            </ul>
          </div>
        ))}

        {menu?.categories.length === 0 && (
          <p className="text-gray-500 text-center py-12">
            No categories yet — add your first one above.
          </p>
        )}
      </div>
    </main>
  );
}

function NewItemForm({
  businessId,
  categoryId,
  onCreated,
}: {
  businessId: string;
  categoryId: string;
  onCreated: () => void;
}) {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsedPrice = parseFloat(price);
    if (!name.trim() || isNaN(parsedPrice) || parsedPrice < 0) return;

    setSaving(true);
    try {
      await createItem(businessId, categoryId, {
        name: name.trim(),
        description: description.trim() || undefined,
        price: parsedPrice,
      });
      onCreated();
    } finally {
      setSaving(false);
    }
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-gray-50 border border-gray-200 rounded-lg p-3 mb-3 space-y-2"
    >
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Item name"
        className="w-full border border-gray-300 rounded px-2 py-1.5 text-sm"
      />
      <input
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        placeholder="Description (optional)"
        className="w-full border border-gray-300 rounded px-2 py-1.5 text-sm"
      />
      <input
        value={price}
        onChange={(e) => setPrice(e.target.value)}
        placeholder="Price (e.g. 12.50)"
        type="number"
        step="0.01"
        min="0"
        className="w-full border border-gray-300 rounded px-2 py-1.5 text-sm"
      />
      <button
        type="submit"
        disabled={saving}
        className="bg-black text-white text-sm px-3 py-1.5 rounded disabled:opacity-50"
      >
        {saving ? 'Saving...' : 'Save item'}
      </button>
    </form>
  );
}
