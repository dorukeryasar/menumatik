'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import {
  getPublicMenu,
  submitOrder,
  type PublicBusiness,
  type CartLine,
} from '@/lib/publicMenu';
import { formatCents } from '@/lib/menu';

export default function PublicMenuPage() {
  const params = useParams<{ slug: string }>();
  const [business, setBusiness] = useState<PublicBusiness | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [cart, setCart] = useState<CartLine[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [orderSubmitted, setOrderSubmitted] = useState<string | null>(null);

  useEffect(() => {
    if (!params.slug) return;
    getPublicMenu(params.slug)
      .then(setBusiness)
      .catch(() => setNotFound(true))
      .finally(() => setLoading(false));
  }, [params.slug]);

  function addToCart(itemId: string, name: string, unitPriceCents: number) {
    setCart((prev) => {
      const existing = prev.find((line) => line.itemId === itemId);
      if (existing) {
        return prev.map((line) =>
          line.itemId === itemId ? { ...line, quantity: line.quantity + 1 } : line,
        );
      }
      return [...prev, { itemId, name, quantity: 1, unitPriceCents }];
    });
  }

  function updateQuantity(itemId: string, delta: number) {
    setCart((prev) =>
      prev
        .map((line) =>
          line.itemId === itemId ? { ...line, quantity: line.quantity + delta } : line,
        )
        .filter((line) => line.quantity > 0),
    );
  }

  const cartTotal = cart.reduce((sum, line) => sum + line.unitPriceCents * line.quantity, 0);
  const cartCount = cart.reduce((sum, line) => sum + line.quantity, 0);

  if (loading) return <div className="p-8 text-center text-gray-500">Loading menu...</div>;
  if (notFound || !business) {
    return <div className="p-8 text-center text-gray-500">Menu not found.</div>;
  }

  const menu = business.menus[0];

  return (
    <main className="max-w-2xl mx-auto pb-24">
      <header className="px-4 py-6 border-b border-gray-100">
        <h1 className="text-2xl font-bold">{business.name}</h1>
        {business.description && (
          <p className="text-gray-600 mt-1">{business.description}</p>
        )}
        <div className="flex gap-3 mt-3 text-sm">
          {business.phone && (
            <a href={`tel:${business.phone}`} className="text-blue-600 underline">
              Call
            </a>
          )}
          {business.whatsappNumber && (
            <a
              href={`https://wa.me/${business.whatsappNumber.replace(/\D/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-green-600 underline"
            >
              WhatsApp
            </a>
          )}
          {business.address && <span className="text-gray-500">{business.address}</span>}
        </div>
      </header>

      {orderSubmitted ? (
        <div className="p-8 text-center">
          <p className="text-lg font-medium mb-2">Order placed! 🎉</p>
          <p className="text-gray-500">Order ID: {orderSubmitted}</p>
          <p className="text-gray-500 mt-1">The restaurant will confirm shortly.</p>
        </div>
      ) : (
        <div className="px-4">
          {menu?.categories.map((category) => (
            <section key={category.id} className="py-6 border-b border-gray-100">
              <h2 className="text-lg font-semibold mb-3">{category.name}</h2>
              <div className="space-y-3">
                {category.items.map((item) => (
                  <div key={item.id} className="flex justify-between items-start gap-3">
                    <div>
                      <p className="font-medium">{item.name}</p>
                      {item.description && (
                        <p className="text-sm text-gray-500">{item.description}</p>
                      )}
                      <p className="text-sm font-medium mt-1">
                        {formatCents(item.priceCents, business.currency)}
                      </p>
                    </div>
                    <button
                      onClick={() => addToCart(item.id, item.name, item.priceCents)}
                      className="bg-black text-white text-sm px-3 py-1.5 rounded-lg shrink-0"
                    >
                      Add
                    </button>
                  </div>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}

      {cartCount > 0 && !orderSubmitted && (
        <button
          onClick={() => setCartOpen(true)}
          className="fixed bottom-4 left-4 right-4 max-w-2xl mx-auto bg-black text-white rounded-xl py-3.5 font-medium flex justify-between px-5"
        >
          <span>{cartCount} item{cartCount > 1 ? 's' : ''} in cart</span>
          <span>{formatCents(cartTotal, business.currency)}</span>
        </button>
      )}

      {cartOpen && (
        <CheckoutSheet
          businessId={business.id}
          cart={cart}
          currency={business.currency}
          updateQuantity={updateQuantity}
          onClose={() => setCartOpen(false)}
          onSuccess={(orderId) => {
            setOrderSubmitted(orderId);
            setCart([]);
            setCartOpen(false);
          }}
        />
      )}
    </main>
  );
}

function CheckoutSheet({
  businessId,
  cart,
  currency,
  updateQuantity,
  onClose,
  onSuccess,
}: {
  businessId: string;
  cart: CartLine[];
  currency: string;
  updateQuantity: (itemId: string, delta: number) => void;
  onClose: () => void;
  onSuccess: (orderId: string) => void;
}) {
  const [guestName, setGuestName] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  const [orderType, setOrderType] = useState<'PICKUP' | 'DELIVERY' | 'DINE_IN'>('PICKUP');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const total = cart.reduce((sum, line) => sum + line.unitPriceCents * line.quantity, 0);

  async function handleSubmit() {
    setSubmitting(true);
    setError(null);
    try {
      // Note: we only send itemId + quantity. The backend looks up
      // the real, current price for each item and computes the
      // total itself — see OrdersService.createOrder. We never send
      // `total` here because the server doesn't trust it anyway.
      const order = await submitOrder(businessId, {
        items: cart.map((line) => ({ itemId: line.itemId, quantity: line.quantity })),
        orderType,
        guestName: guestName || undefined,
        guestPhone: guestPhone || undefined,
      });
      onSuccess(order.id);
    } catch (err) {
      setError('Could not place order. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 flex items-end justify-center z-50">
      <div className="bg-white w-full max-w-2xl rounded-t-2xl p-5 max-h-[85vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Your order</h2>
          <button onClick={onClose} className="text-gray-400">
            Close
          </button>
        </div>

        <ul className="divide-y divide-gray-100 mb-4">
          {cart.map((line) => (
            <li key={line.itemId} className="py-2 flex justify-between items-center">
              <span>{line.name}</span>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => updateQuantity(line.itemId, -1)}
                  className="w-7 h-7 border border-gray-300 rounded-full"
                >
                  −
                </button>
                <span>{line.quantity}</span>
                <button
                  onClick={() => updateQuantity(line.itemId, 1)}
                  className="w-7 h-7 border border-gray-300 rounded-full"
                >
                  +
                </button>
              </div>
            </li>
          ))}
        </ul>

        <div className="flex justify-between font-medium mb-4">
          <span>Total</span>
          <span>{formatCents(total, currency)}</span>
        </div>

        <div className="flex gap-2 mb-4">
          {(['PICKUP', 'DELIVERY', 'DINE_IN'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setOrderType(type)}
              className={`flex-1 text-sm py-2 rounded-lg border ${
                orderType === type ? 'bg-black text-white' : 'border-gray-300'
              }`}
            >
              {type.replace('_', ' ')}
            </button>
          ))}
        </div>

        <input
          value={guestName}
          onChange={(e) => setGuestName(e.target.value)}
          placeholder="Your name"
          className="w-full mb-2 border border-gray-300 rounded-lg px-3 py-2"
        />
        <input
          value={guestPhone}
          onChange={(e) => setGuestPhone(e.target.value)}
          placeholder="Phone number"
          className="w-full mb-4 border border-gray-300 rounded-lg px-3 py-2"
        />

        {error && <p className="text-sm text-red-600 mb-3">{error}</p>}

        {/*
          NOTE: payment integration isn't wired in here yet. In the
          roadmap's Sprint 8-9, this button's flow becomes:
          1. POST /public/businesses/:id/orders (creates PENDING order)
          2. Backend creates a Stripe PaymentIntent, returns client_secret
          3. Frontend mounts Stripe Elements/Checkout with that secret
          4. On success, Stripe webhook flips order to CONFIRMED/PAID
          For now this submits a PENDING/UNPAID order directly, which
          is fine for "pay at pickup" style businesses to start with.
        */}
        <button
          onClick={handleSubmit}
          disabled={submitting}
          className="w-full bg-black text-white py-3 rounded-lg font-medium disabled:opacity-50"
        >
          {submitting ? 'Placing order...' : `Place order — ${formatCents(total, currency)}`}
        </button>
      </div>
    </div>
  );
}
