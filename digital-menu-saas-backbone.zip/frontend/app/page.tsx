import Link from 'next/link';

export default function HomePage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center px-4 text-center">
      <h1 className="text-4xl font-bold mb-4">Digital Menu Platform</h1>
      <p className="text-gray-600 mb-8 max-w-md">
        Build a beautiful digital menu and start taking orders online — no
        app download required for your customers.
      </p>
      <div className="flex gap-4">
        <Link
          href="/register"
          className="bg-black text-white px-6 py-3 rounded-lg font-medium hover:bg-gray-800"
        >
          Get Started
        </Link>
        <Link
          href="/login"
          className="border border-gray-300 px-6 py-3 rounded-lg font-medium hover:bg-gray-100"
        >
          Log In
        </Link>
      </div>
    </main>
  );
}
